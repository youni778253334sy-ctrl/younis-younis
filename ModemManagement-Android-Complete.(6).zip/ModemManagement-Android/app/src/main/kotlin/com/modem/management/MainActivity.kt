package com.modem.management

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        val welcomeText = findViewById<TextView>(R.id.welcome_text)
        welcomeText.text = "مرحباً بك في تطبيق إدارة الشبكة\nModem Management System"
    }
}
